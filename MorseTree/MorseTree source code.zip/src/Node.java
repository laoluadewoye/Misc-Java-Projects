public class Node {
    int number;
    char character;
    int level;
    Node left;
    Node right;
    public Node(int number, char character, int level) {
        this.number = number;
        this.character = character;
        this.level = level;
    }
}
